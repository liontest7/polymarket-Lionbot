"""
src/data/binance_feed.py
Real-time BTC price feed from Binance WebSocket.
Maintains a rolling 60-second price history for delta calculations.
"""

import asyncio
import json
import time
from collections import deque
from typing import Optional, Callable, Awaitable
import websockets
from loguru import logger

from src.models import BTCPrice


BINANCE_WS_URL = "wss://stream.binance.com:9443/ws/btcusdt@trade"
RECONNECT_DELAY = 3  # seconds before reconnect attempt


class BinanceFeed:
    """
    Streams real-time BTC/USDT trade prices from Binance.
    Stores last 60 seconds of prices for delta calculations.
    Auto-reconnects on disconnect.
    """

    def __init__(self) -> None:
        self._current: Optional[BTCPrice] = None
        self._history: deque[BTCPrice] = deque(maxlen=600)  # ~60s at 10 trades/s
        self._callbacks: list[Callable[[BTCPrice], Awaitable[None]]] = []
        self._running = False

    @property
    def current_price(self) -> Optional[BTCPrice]:
        return self._current

    @property
    def is_healthy(self) -> bool:
        if self._current is None:
            return False
        return self._current.age_seconds < 5.0

    def on_price(self, callback: Callable[[BTCPrice], Awaitable[None]]) -> None:
        """Register async callback for every new price tick."""
        self._callbacks.append(callback)

    def get_price_n_seconds_ago(self, n: float) -> Optional[BTCPrice]:
        """Find the closest price from ~n seconds ago."""
        target_ts = time.time() - n
        best = None
        best_diff = float("inf")
        for p in self._history:
            diff = abs(p.timestamp - target_ts)
            if diff < best_diff:
                best_diff = diff
                best = p
        return best

    def get_delta_pct(self, lookback_seconds: float = 20.0) -> Optional[float]:
        """
        Calculate % price change over last N seconds.
        Returns None if not enough data.
        """
        if self._current is None:
            return None
        past = self.get_price_n_seconds_ago(lookback_seconds)
        if past is None or past.age_seconds < (lookback_seconds * 0.5):
            return None  # not enough history yet
        delta = (self._current.price - past.price) / past.price * 100
        return delta

    async def start(self) -> None:
        """Start streaming. Runs forever with auto-reconnect."""
        self._running = True
        logger.info("BinanceFeed starting...")
        while self._running:
            try:
                await self._stream()
            except Exception as e:
                logger.warning(f"BinanceFeed disconnected: {e} — reconnecting in {RECONNECT_DELAY}s")
                await asyncio.sleep(RECONNECT_DELAY)

    async def stop(self) -> None:
        self._running = False
        logger.info("BinanceFeed stopped")

    async def _stream(self) -> None:
        async with websockets.connect(
            BINANCE_WS_URL,
            ping_interval=20,
            ping_timeout=10,
            close_timeout=5,
        ) as ws:
            logger.success("BinanceFeed connected to Binance")
            async for raw in ws:
                if not self._running:
                    break
                try:
                    msg = json.loads(raw)
                    price = BTCPrice(
                        price=float(msg["p"]),
                        timestamp=float(msg["T"]) / 1000.0,  # ms → seconds
                        source="binance",
                    )
                    self._current = price
                    self._history.append(price)

                    # Fire callbacks
                    for cb in self._callbacks:
                        asyncio.create_task(cb(price))

                except (KeyError, ValueError) as e:
                    logger.debug(f"BinanceFeed parse error: {e}")
