"""
src/data/polymarket_feed.py
Finds and tracks active 5-minute BTC Up/Down markets on Polymarket.
Fetches order book prices for signal calculation.
"""

import asyncio
import time
from typing import Optional
import httpx
from loguru import logger

from src.models import PolyWindow


GAMMA_API = "https://gamma-api.polymarket.com"
CLOB_API = "https://clob.polymarket.com"

# BTC 5-min slug pattern: btc-up-or-down-in-the-next-5-minutes-{window_ts}
# Polymarket slugs can vary — we search by tag
SEARCH_TAGS = ["BTC", "5", "minutes", "up", "down"]


class PolymarketFeed:
    """
    Discovers and tracks active 5-minute BTC Up/Down windows.
    Polls Gamma API every 30 seconds for active markets.
    Fetches live order book midpoints for token pricing.
    """

    def __init__(self) -> None:
        self._current_window: Optional[PolyWindow] = None
        self._client = httpx.AsyncClient(timeout=10.0)
        self._running = False

    @property
    def current_window(self) -> Optional[PolyWindow]:
        return self._current_window

    @property
    def is_healthy(self) -> bool:
        if self._current_window is None:
            return False
        return self._current_window.is_active

    async def start(self) -> None:
        self._running = True
        logger.info("PolymarketFeed starting...")
        while self._running:
            try:
                await self._refresh_window()
            except Exception as e:
                logger.warning(f"PolymarketFeed refresh error: {e}")
            await asyncio.sleep(15)

    async def stop(self) -> None:
        self._running = False
        await self._client.aclose()

    async def _refresh_window(self) -> None:
        """Find the currently active 5-min BTC window."""
        now = time.time()
        window_ts = int(now - (now % 300))
        close_ts = window_ts + 300

        # Check if we already have this window
        if (
            self._current_window
            and self._current_window.window_ts == window_ts
        ):
            return

        logger.info(f"Searching for BTC 5-min window ts={window_ts}")

        # Search Gamma API for active BTC 5-min markets
        try:
            resp = await self._client.get(
                f"{GAMMA_API}/markets",
                params={
                    "active": "true",
                    "closed": "false",
                    "tag_slug": "crypto",
                    "limit": 100,
                },
            )
            resp.raise_for_status()
            markets = resp.json()
        except Exception as e:
            logger.error(f"Gamma API error: {e}")
            return

        # Filter for BTC 5-min markets
        btc_5m = [
            m for m in markets
            if self._is_btc_5min(m)
        ]

        if not btc_5m:
            logger.debug("No active BTC 5-min markets found")
            return

        market = btc_5m[0]
        logger.info(f"Found BTC 5-min market: {market.get('slug', 'unknown')}")

        # Extract token IDs (YES=UP, NO=DOWN for standard binary)
        tokens = market.get("tokens", [])
        token_up = next((t["token_id"] for t in tokens if t.get("outcome", "").upper() == "YES"), None)
        token_down = next((t["token_id"] for t in tokens if t.get("outcome", "").upper() == "NO"), None)

        if not token_up or not token_down:
            logger.warning(f"Could not extract token IDs from market: {market.get('id')}")
            return

        # Get BTC open price from market question or Chainlink
        open_price = self._parse_open_price(market)

        self._current_window = PolyWindow(
            window_ts=window_ts,
            close_ts=close_ts,
            market_id=market["id"],
            token_id_up=token_up,
            token_id_down=token_down,
            open_price=open_price,
        )
        logger.success(
            f"Active window: {self._current_window.slug} | "
            f"closes in {self._current_window.seconds_remaining:.0f}s | "
            f"open_price=${open_price:,.0f}"
        )

    async def get_token_price(self, token_id: str) -> Optional[float]:
        """Get midpoint price for a token from CLOB order book."""
        try:
            resp = await self._client.get(
                f"{CLOB_API}/midpoint",
                params={"token_id": token_id},
            )
            resp.raise_for_status()
            data = resp.json()
            return float(data.get("mid", 0))
        except Exception as e:
            logger.debug(f"Token price fetch error ({token_id[:8]}...): {e}")
            return None

    async def get_order_book(self, token_id: str) -> Optional[dict]:
        """Get full order book for a token."""
        try:
            resp = await self._client.get(
                f"{CLOB_API}/book",
                params={"token_id": token_id},
            )
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            logger.debug(f"Order book fetch error: {e}")
            return None

    def _is_btc_5min(self, market: dict) -> bool:
        """Heuristic: is this a BTC 5-minute Up/Down market?"""
        question = market.get("question", "").lower()
        slug = market.get("slug", "").lower()
        keywords = ["btc", "bitcoin", "5", "minute", "up", "down"]
        text = question + slug
        matches = sum(1 for kw in keywords if kw in text)
        return matches >= 4

    def _parse_open_price(self, market: dict) -> float:
        """Try to extract BTC open price from market metadata."""
        # Try various fields Polymarket uses
        for field in ["initialAnswer", "startPrice", "benchmarkPrice"]:
            val = market.get(field)
            if val:
                try:
                    return float(val)
                except (ValueError, TypeError):
                    pass
        return 0.0  # fallback — signal engine will still work
