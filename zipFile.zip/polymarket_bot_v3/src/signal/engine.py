"""
src/signal/engine.py
Core signal engine — decides whether to trade, which side, at what size.

Strategy:
  1. Wait until T-25 seconds before window close
  2. Calculate BTC delta (% move in last 20 seconds)
  3. If delta > threshold → signal exists
  4. Calculate token price and expected edge after fees
  5. If edge > threshold → return Signal

Edge formula:
  edge = P(win) * payout - token_price - fees
  P(win) is estimated from BTC delta strength (not naive 50/50)
"""

import time
from typing import Optional
from loguru import logger

from src.models import Signal, PolyWindow, Side
from src.data.binance_feed import BinanceFeed
from src.data.polymarket_feed import PolymarketFeed
from config.settings import Settings


# Sigmoid-like mapping: delta_pct → estimated P(win)
# Based on observed Polymarket 5-min market behavior
# At T-20s, if BTC moved 0.10%, market is ~80% likely to resolve that way
DELTA_TO_WIN_PROB = [
    (0.03, 0.56),
    (0.05, 0.61),
    (0.07, 0.66),
    (0.10, 0.72),
    (0.15, 0.80),
    (0.20, 0.87),
    (0.30, 0.93),
]


def estimate_win_probability(delta_abs: float) -> float:
    """
    Map absolute BTC delta % to estimated probability of winning.
    Uses linear interpolation between calibrated points.
    """
    if delta_abs <= DELTA_TO_WIN_PROB[0][0]:
        return DELTA_TO_WIN_PROB[0][1]
    if delta_abs >= DELTA_TO_WIN_PROB[-1][0]:
        return DELTA_TO_WIN_PROB[-1][1]

    for i in range(len(DELTA_TO_WIN_PROB) - 1):
        d0, p0 = DELTA_TO_WIN_PROB[i]
        d1, p1 = DELTA_TO_WIN_PROB[i + 1]
        if d0 <= delta_abs <= d1:
            # Linear interpolation
            t = (delta_abs - d0) / (d1 - d0)
            return p0 + t * (p1 - p0)

    return 0.5  # fallback


class SignalEngine:
    """
    Evaluates market conditions every second and produces trading signals.
    """

    def __init__(
        self,
        binance: BinanceFeed,
        polymarket: PolymarketFeed,
        settings: Settings,
    ) -> None:
        self._binance = binance
        self._polymarket = polymarket
        self._settings = settings
        self._last_signal_window: Optional[int] = None

    async def evaluate(self) -> Optional[Signal]:
        """
        Run signal evaluation. Returns Signal if tradeable, None otherwise.
        Call this every second from main loop.
        """
        window = self._polymarket.current_window
        if window is None:
            logger.debug("No active window")
            return None

        # Already traded this window
        if self._last_signal_window == window.window_ts:
            return None

        # Only evaluate in entry window (last N seconds)
        secs_remaining = window.seconds_remaining
        if secs_remaining > self._settings.entry_window_seconds:
            logger.debug(f"Too early: {secs_remaining:.0f}s remaining (threshold={self._settings.entry_window_seconds}s)")
            return None

        if secs_remaining < 5:
            logger.warning(f"Too late: only {secs_remaining:.1f}s remaining, skipping")
            return None

        # Check data freshness
        if not self._binance.is_healthy:
            logger.warning("Binance feed unhealthy, skipping signal")
            return None

        # Calculate BTC delta
        delta_pct = self._binance.get_delta_pct(lookback_seconds=20.0)
        if delta_pct is None:
            logger.debug("Insufficient price history for delta calculation")
            return None

        delta_abs = abs(delta_pct)

        if delta_abs < self._settings.min_btc_delta_pct:
            logger.debug(
                f"Delta too small: {delta_abs:.3f}% < {self._settings.min_btc_delta_pct}% threshold"
            )
            return None

        # Determine direction
        side: Side = "UP" if delta_pct > 0 else "DOWN"
        token_id = window.token_id_up if side == "UP" else window.token_id_down

        # Get live token price
        token_price = await self._polymarket.get_token_price(token_id)
        if token_price is None or token_price <= 0:
            logger.warning("Could not fetch token price")
            return None

        if token_price >= 0.98:
            logger.debug(f"Token price {token_price} too high — market already priced in")
            return None

        if token_price <= 0.02:
            logger.debug(f"Token price {token_price} suspiciously low — skipping")
            return None

        # Calculate edge
        win_prob = estimate_win_probability(delta_abs)
        expected_value = win_prob * 1.0  # binary: win = $1 per share
        fee = self._settings.taker_fee_pct * token_price
        edge = expected_value - token_price - fee

        confidence = win_prob  # for now, confidence = win probability

        logger.info(
            f"Signal: side={side} | delta={delta_pct:+.3f}% | "
            f"token_price={token_price:.3f} | win_prob={win_prob:.2f} | "
            f"edge={edge:.3f} | secs_remaining={secs_remaining:.1f}"
        )

        if edge < self._settings.min_edge_after_fees:
            logger.info(
                f"Edge {edge:.3f} below threshold {self._settings.min_edge_after_fees} — no trade"
            )
            return None

        signal = Signal(
            side=side,
            btc_delta_pct=delta_pct,
            token_price=token_price,
            expected_payout=1.0,
            edge_after_fees=edge,
            confidence=confidence,
        )

        if signal.is_tradeable:
            self._last_signal_window = window.window_ts
            logger.success(
                f"TRADEABLE SIGNAL → {side} | edge={edge:.3f} | confidence={confidence:.2f}"
            )
            return signal

        return None
