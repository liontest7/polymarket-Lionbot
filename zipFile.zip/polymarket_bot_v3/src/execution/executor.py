"""
src/execution/executor.py
Trade execution — paper mode (simulation) and live mode (real orders).

Paper mode: simulates fills, logs everything, calculates PNL.
Live mode: uses py-clob-client to place real Polymarket orders.

IMPORTANT: In live mode, the bot places MAKER limit orders to avoid
taker fees. It posts at current mid and waits for fill.
"""

import asyncio
import time
import uuid
from typing import Optional
from loguru import logger

from src.models import Signal, Trade, PolyWindow
from src.risk.manager import RiskManager, RiskStatus
from config.settings import Settings


class PaperExecutor:
    """
    Simulates trade execution without placing real orders.
    Assumes fills at the signal's token_price (realistic for liquid markets).
    Simulates binary resolution at window close.
    """

    def __init__(self, settings: Settings, risk: RiskManager) -> None:
        self._settings = settings
        self._risk = risk
        self._open_trades: dict[str, Trade] = {}

    async def execute(
        self,
        signal: Signal,
        window: PolyWindow,
        risk_status: RiskStatus,
    ) -> Optional[Trade]:
        """Open a paper trade."""
        trade_id = f"paper-{uuid.uuid4().hex[:8]}"

        token_id = window.token_id_up if signal.side == "UP" else window.token_id_down
        shares = risk_status.suggested_shares
        size_usd = risk_status.suggested_size_usd
        fee = size_usd * self._settings.taker_fee_pct

        trade = Trade(
            id=trade_id,
            window_ts=window.window_ts,
            side=signal.side,
            token_id=token_id,
            shares=shares,
            entry_price=signal.token_price,
            entry_time=time.time(),
            size_usd=size_usd,
            mode="paper",
            fees_paid=fee,
            notes=f"delta={signal.btc_delta_pct:+.3f}% edge={signal.edge_after_fees:.3f}",
        )

        self._open_trades[trade_id] = trade
        self._risk.record_trade_open(trade)

        logger.success(
            f"[PAPER] Trade opened | id={trade_id} | side={signal.side} | "
            f"shares={shares:.1f} | price={signal.token_price:.3f} | "
            f"size=${size_usd:.2f} | closes in {window.seconds_remaining:.0f}s"
        )

        # Schedule resolution check at window close
        asyncio.create_task(
            self._wait_for_resolution(trade, window)
        )

        return trade

    async def _wait_for_resolution(self, trade: Trade, window: PolyWindow) -> None:
        """Wait for window to close and then resolve the paper trade."""
        wait_seconds = max(0, window.seconds_remaining + 10)  # +10s buffer
        logger.debug(f"[PAPER] Waiting {wait_seconds:.0f}s for resolution of {trade.id}")
        await asyncio.sleep(wait_seconds)

        # In paper mode, we need the actual BTC close price to determine winner
        # For now, we'll fetch from Polymarket resolution or use a placeholder
        # In production, hook this to actual Chainlink/Polymarket resolution
        await self._resolve_trade(trade, window)

    async def _resolve_trade(self, trade: Trade, window: PolyWindow) -> None:
        """
        Resolve paper trade. Fetches final token price to determine outcome.
        A resolved winning token trades at $1.00, losing at $0.00.
        """
        import httpx
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(
                    "https://clob.polymarket.com/midpoint",
                    params={"token_id": trade.token_id},
                )
                data = resp.json()
                final_price = float(data.get("mid", 0))
        except Exception as e:
            logger.warning(f"Could not fetch resolution price for {trade.id}: {e}")
            final_price = trade.entry_price  # neutral fallback

        # Determine result: price near 1.0 = win, near 0.0 = loss
        if final_price >= 0.85:
            trade.result = "WIN"
            trade.exit_price = 1.0
            trade.pnl_usd = trade.shares * (1.0 - trade.entry_price) - trade.fees_paid
        elif final_price <= 0.15:
            trade.result = "LOSS"
            trade.exit_price = 0.0
            trade.pnl_usd = -trade.size_usd - trade.fees_paid
        else:
            # Market still resolving — check again in 60s
            logger.debug(f"Market {trade.id} still resolving (mid={final_price:.3f}), rechecking...")
            await asyncio.sleep(60)
            await self._resolve_trade(trade, window)
            return

        trade.exit_time = time.time()
        self._risk.record_trade_close(trade)
        del self._open_trades[trade.id]

        logger.info(
            f"[PAPER] Trade resolved | id={trade.id} | result={trade.result} | "
            f"pnl=${trade.pnl_usd:+.2f}"
        )


class LiveExecutor:
    """
    Places real orders on Polymarket via py-clob-client.
    Uses MAKER limit orders to avoid taker fees.

    WARNING: This uses real money. Only activate after extensive paper trading.
    """

    def __init__(self, settings: Settings, risk: RiskManager) -> None:
        self._settings = settings
        self._risk = risk
        self._client = None
        self._open_trades: dict[str, Trade] = {}

    def _get_client(self):
        """Lazy-init CLOB client."""
        if self._client is None:
            try:
                from py_clob_client.client import ClobClient
                from py_clob_client.clob_types import ApiCreds

                self._client = ClobClient(
                    host="https://clob.polymarket.com",
                    chain_id=137,  # Polygon
                    key=self._settings.polymarket_pk,
                    creds=ApiCreds(
                        api_key=self._settings.polymarket_api_key,
                        api_secret=self._settings.polymarket_api_secret,
                        api_passphrase=self._settings.polymarket_api_passphrase,
                    ),
                )
                logger.success("CLOB client initialized")
            except ImportError:
                logger.error("py-clob-client not installed. Run: pip install py-clob-client")
                raise
        return self._client

    async def execute(
        self,
        signal: Signal,
        window: PolyWindow,
        risk_status: RiskStatus,
    ) -> Optional[Trade]:
        """Place a real maker limit order on Polymarket."""
        client = self._get_client()
        trade_id = f"live-{uuid.uuid4().hex[:8]}"
        token_id = window.token_id_up if signal.side == "UP" else window.token_id_down

        # Maker order: post at current mid price (slightly better for us)
        # This avoids taker fees
        limit_price = round(signal.token_price, 2)
        shares = round(risk_status.suggested_shares, 0)
        size_usd = shares * limit_price

        logger.warning(
            f"[LIVE] About to place REAL order | "
            f"side={signal.side} | shares={shares} | price={limit_price} | "
            f"size=${size_usd:.2f}"
        )

        try:
            from py_clob_client.clob_types import OrderArgs, OrderType

            order_args = OrderArgs(
                token_id=token_id,
                price=limit_price,
                size=shares,
                side="BUY",
                order_type=OrderType.GTC,
            )

            # Run blocking SDK call in thread pool
            loop = asyncio.get_event_loop()
            resp = await loop.run_in_executor(
                None, lambda: client.create_and_post_order(order_args)
            )

            order_id = resp.get("orderID") if isinstance(resp, dict) else str(resp)
            fee = size_usd * self._settings.maker_fee_pct

            trade = Trade(
                id=trade_id,
                window_ts=window.window_ts,
                side=signal.side,
                token_id=token_id,
                shares=shares,
                entry_price=limit_price,
                entry_time=time.time(),
                size_usd=size_usd,
                mode="live",
                order_id=order_id,
                fees_paid=fee,
                notes=f"delta={signal.btc_delta_pct:+.3f}% edge={signal.edge_after_fees:.3f}",
            )

            self._open_trades[trade_id] = trade
            self._risk.record_trade_open(trade)

            logger.success(
                f"[LIVE] Order placed | order_id={order_id} | "
                f"side={signal.side} | shares={shares} | price={limit_price}"
            )
            return trade

        except Exception as e:
            logger.error(f"[LIVE] Order failed: {e}")
            return None


def create_executor(settings: Settings, risk: RiskManager):
    """Factory: returns correct executor based on trading mode."""
    if settings.trading_mode == "paper":
        logger.info("Executor: PAPER MODE (no real money)")
        return PaperExecutor(settings, risk)
    else:
        logger.warning("⚠️  Executor: LIVE MODE — REAL MONEY ACTIVE ⚠️")
        return LiveExecutor(settings, risk)
