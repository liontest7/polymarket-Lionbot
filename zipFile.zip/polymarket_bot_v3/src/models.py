"""
src/models.py
Shared data models across all modules
"""

from dataclasses import dataclass, field
from typing import Literal, Optional
from datetime import datetime
import time


Side = Literal["UP", "DOWN"]
TradeResult = Literal["WIN", "LOSS", "PENDING", "CANCELLED"]
OrderSide = Literal["BUY", "SELL"]


@dataclass
class BTCPrice:
    price: float
    timestamp: float  # unix seconds
    source: str = "binance"

    @property
    def age_seconds(self) -> float:
        return time.time() - self.timestamp


@dataclass
class PolyWindow:
    """A 5-minute Polymarket BTC Up/Down window."""
    window_ts: int        # unix timestamp of window start (divisible by 300)
    close_ts: int         # window_ts + 300
    market_id: str        # Polymarket market ID
    token_id_up: str      # token ID for UP
    token_id_down: str    # token ID for DOWN
    open_price: float     # BTC price at window open (Chainlink)

    @property
    def seconds_remaining(self) -> float:
        return self.close_ts - time.time()

    @property
    def slug(self) -> str:
        return f"btc-updown-5m-{self.window_ts}"

    @property
    def is_active(self) -> bool:
        return 0 < self.seconds_remaining < 300


@dataclass
class Signal:
    """Trading signal output from SignalEngine."""
    side: Side
    btc_delta_pct: float      # % move of BTC in last 20s
    token_price: float        # current price of winning token (0-1)
    expected_payout: float    # = 1.0 (binary market)
    edge_after_fees: float    # expected value - cost - fees
    confidence: float         # 0.0 to 1.0
    timestamp: float = field(default_factory=time.time)

    @property
    def is_tradeable(self) -> bool:
        return self.edge_after_fees > 0 and self.confidence > 0.55


@dataclass
class Trade:
    """A single trade execution record."""
    id: str
    window_ts: int
    side: Side
    token_id: str
    shares: float
    entry_price: float
    entry_time: float
    size_usd: float
    mode: Literal["paper", "live"]
    order_id: Optional[str] = None
    exit_price: Optional[float] = None
    exit_time: Optional[float] = None
    result: TradeResult = "PENDING"
    pnl_usd: float = 0.0
    fees_paid: float = 0.0
    notes: str = ""

    @property
    def is_closed(self) -> bool:
        return self.result in ("WIN", "LOSS", "CANCELLED")


@dataclass
class DailyStats:
    date: str
    trades: int = 0
    wins: int = 0
    losses: int = 0
    total_pnl: float = 0.0
    total_fees: float = 0.0
    gross_pnl: float = 0.0

    @property
    def win_rate(self) -> float:
        if self.trades == 0:
            return 0.0
        return self.wins / self.trades

    @property
    def net_pnl(self) -> float:
        return self.total_pnl - self.total_fees
