"""
run.py — Entry point.
Starts FastAPI web server + bot together.
Browser opens automatically at http://localhost:8080
All settings and controls are in the browser UI.
"""

import asyncio
import sys
import webbrowser
import threading
import time
from pathlib import Path


def main():
    args = sys.argv[1:]
    live_mode = "--live" in args

    from config.logger import setup_logger
    from config.settings import Settings

    # Load settings fresh — allow env override for live mode
    import os
    if live_mode:
        os.environ["TRADING_MODE"] = "live"

    s = Settings()
    setup_logger(s.log_level, s.log_file)

    mode_label = "LIVE (real money)" if s.trading_mode == "live" else "PAPER (demo)"
    print("")
    print("  POLYMARKET BOT v3")
    print(f"  Mode:    {mode_label}")
    print(f"  Capital: ${s.capital_usd}")
    print(f"  Web UI:  http://localhost:8080")
    print("")
    print("  Opening browser automatically...")
    print("  Press Ctrl+C to stop.")
    print("")

    # ── Register the / route BEFORE starting uvicorn ──
    from src.api.server import app
    from fastapi.responses import HTMLResponse
    from fastapi.staticfiles import StaticFiles

    html_path = Path(__file__).parent / "web" / "templates" / "dashboard.html"
    static_path = Path(__file__).parent / "web" / "static"

    # Mount static files if folder exists and has content
    if static_path.exists():
        try:
            app.mount("/static", StaticFiles(directory=str(static_path)), name="static")
        except Exception:
            pass  # empty folder is fine

    @app.get("/", response_class=HTMLResponse)
    async def serve_dashboard():
        if html_path.exists():
            return HTMLResponse(html_path.read_text(encoding="utf-8"))
        return HTMLResponse(
            "<h1 style='font-family:monospace;color:#0f0;background:#000;padding:40px'>"
            "Dashboard file missing.<br>Check web/templates/dashboard.html</h1>"
        )

    # ── Start uvicorn in background thread ──
    server_ready = threading.Event()

    def start_web():
        import uvicorn

        class NotifyServer(uvicorn.Server):
            async def startup(self, sockets=None):
                await super().startup(sockets)
                server_ready.set()

        config = uvicorn.Config(
            app,
            host="0.0.0.0",
            port=8080,
            log_level="warning",
            access_log=False,
        )
        NotifyServer(config).run()

    web_thread = threading.Thread(target=start_web, daemon=True)
    web_thread.start()

    # Wait for server to be ready, then open browser
    def open_browser():
        ready = server_ready.wait(timeout=10)
        time.sleep(0.5)  # tiny buffer after ready signal
        webbrowser.open("http://localhost:8080")
        if not ready:
            print("  Warning: server may not be ready yet, opening browser anyway...")

    threading.Thread(target=open_browser, daemon=True).start()

    # ── Run bot (blocking) ──
    async def run_bot():
        from src.bot import PolyBot
        bot = PolyBot(s)
        await bot.run()

    try:
        asyncio.run(run_bot())
    except KeyboardInterrupt:
        print("\n  Bot stopped.")


if __name__ == "__main__":
    main()
